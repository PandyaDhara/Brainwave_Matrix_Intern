"""This module only makes the version available for dynamic versioning"""
VERSION = "1.20240129.2"
